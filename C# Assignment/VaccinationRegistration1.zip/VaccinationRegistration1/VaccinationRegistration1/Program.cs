﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaccinationRegistration1
{
    class Program
    {
        private static List<BeneficiaryDetails> beneficiary = new List<BeneficiaryDetails>();
        private static List<VaccinationDetails> vaccinationDetails = new List<VaccinationDetails>();
        static void Main(string[] args)
        {
            string option = "true";

            while (option.Equals("true"))
            {
                Console.WriteLine("----------------------------");
                Console.WriteLine("Enter 1 for New User");
                Console.WriteLine("Enter 2 for Login");
                Console.WriteLine("Enter 3 for exit");
                Console.WriteLine("Enter your choice");
                Console.WriteLine("-----------------------------");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddNewUser();
                        break;
                    case 2:
                        LoginUser();
                        break;
                    case 3:
                        option = "false";
                        break;
                    default:
                        Console.WriteLine("Enter Valid number");
                        break;
                }
            }
            Console.WriteLine("The program has ended successfully: ");
            Console.ReadKey();
        }
        private static void AddNewUser()
        {
            Console.WriteLine("Enter the user name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your age: ");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your phone number:");
            long mobilenumber = long.Parse(Console.ReadLine());
            BeneficiaryDetails user = new BeneficiaryDetails(name, age, mobilenumber);
            beneficiary.Add(user);

        }
        private static void LoginUser()
        {
            foreach (BeneficiaryDetails users in beneficiary)
            {


                Console.Write(users.userId + " |");
                Console.Write(users.userName + " ");
                Console.WriteLine("\n");

            }

            string opt = "true";
            while (opt.Equals("true"))
            {
                string option = "true";
                Console.WriteLine("Enter your UserID :");
                int userId = int.Parse(Console.ReadLine());
                int check = CheckUser(userId);
                while (option.Equals("true"))
                {
                    if (check == 1)
                    {
                        Console.WriteLine("-----------------------------");
                        Console.WriteLine("you have logged in successfully");
                        Console.WriteLine("------------------------------");
                        Console.WriteLine("Enter 1 for booking vaccine");
                        Console.WriteLine("Enter 2 for vaccination history");
                        Console.WriteLine("Enter 3 for exit");
                        Console.WriteLine("Enter your choice: ");
                        Console.WriteLine("-----------------------");
                        int choice = int.Parse(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                BookVaccine(userId);
                                break;
                            case 2:
                                VaccinationDetails(userId);
                                break;
                            case 3:
                                option = "false";
                                opt = "false";
                                break;
                            default:
                                Console.WriteLine("Enter valid number");
                                break;
                        }
                    }
                    else if (check == 0)
                    {
                        string ch = "true";
                        while (ch.Equals("true"))
                        {
                            Console.WriteLine("your user id is invalid \n");
                            Console.WriteLine("Enter 0 for rentering userID \n or click 1 to go main menu");
                            int choice = int.Parse(Console.ReadLine());
                            if (choice == 0)
                            {
                                option = "false";
                                ch = "false";

                            }
                            else if (choice == 1)
                            {
                                option = "false";
                                opt = "false";
                                ch = "false";
                            }
                            else
                            {
                                ch = "true";
                            }
                        }
                    }
                }
            }
        }
        private static int CheckUser(int userid)
        {
            int count = 0;
            foreach (BeneficiaryDetails users in beneficiary)
            {
                if (users.userId == userid)
                {

                    count++;
                }

            }
            if (count != 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }
        private static void BookVaccine(int userid)
        {
            string name = string.Empty;
            int coun = 0;
            string ch = "true";
            string vaccinetype = string.Empty;
            //string ch = "true";
            while (ch.Equals("true"))
            {
                Console.WriteLine("----------------------");
                Console.WriteLine("Enter 1 for having Covaxin");
                Console.WriteLine("Enter 2 for having Covidshield");
                Console.WriteLine("Enter 3 for having sputnik");
                Console.WriteLine("----------------------------");
                Console.WriteLine("Enter your choice");
                int choice = int.Parse(Console.ReadLine());

                if ((VaccineType)choice == VaccineType.Covaxin)
                {
                    vaccinetype = "Covaxin";
                    ch = "false";
                }
                else if ((VaccineType)choice == VaccineType.Covidshield)
                {
                    vaccinetype = "Covidshield";
                    ch = "false";

                }
                else if ((VaccineType)choice == VaccineType.sputnik)
                {
                    vaccinetype = "sputnik";
                    ch = "false";
                }
                else
                {
                    Console.WriteLine("Invalid number entered Enter Valid number: ");
                    ch = "true";
                }
            }
            foreach(BeneficiaryDetails users in beneficiary)
            {
                if(userid==users.userId)
                {
                    name = users.userName;
                }
            }
            foreach(VaccinationDetails users in vaccinationDetails)
            {
                if(userid==users.userId)
                {
                    coun++;
                }
            }
            if(coun==0)
            {
                DateTime date = DateTime.Now;
                date = date.AddDays(30);
                Console.WriteLine("you had " + vaccinetype + " successfully of first dose");
                Console.WriteLine("The next due date is" + date);
                VaccinationDetails vaccine = new VaccinationDetails(userid, name, vaccinetype, 1, date);
                vaccinationDetails.Add(vaccine);
            }
            if(coun==1)
            {
                string vaccinenme = String.Empty;
                int count = 0;
                DateTime date=DateTime.Now;
                foreach (VaccinationDetails users in vaccinationDetails)
                {
                    if ((userid == users.userId)&&(users.vaccinename==vaccinetype))
                    {
                        count++;
                        vaccinenme = users.vaccinename;
                        
                    }
                }
                if (count != 0)
                {
                    date = date.AddDays(60);
                    Console.WriteLine("you had " + vaccinetype + " successfully of second dose");
                    Console.WriteLine("you have completed all vaccination");
                    VaccinationDetails vaccine = new VaccinationDetails(userid,name, vaccinenme, 2,date);
                    vaccinationDetails.Add(vaccine);
                }
                else
                {
                    Console.WriteLine("you have entered vaccinnation type wrongly the vaccine you had was " + vaccinenme);
                }
            }
            if(coun>=2)
            {
                Console.WriteLine("you had all two doses. thanks for taking part in the drive");
            }
        }
        private static void VaccinationDetails(int userId)
        {
            int count = 0;
            foreach(VaccinationDetails vaccine in vaccinationDetails)
            {
                if(userId==vaccine.userId)
                {
                    Console.WriteLine("UserId: "+vaccine.userId+" |"+"Username: "+vaccine.username+" |Vaccinetype: "+vaccine.vaccinename+"| Dose: "+vaccine.dose);
                    count++;
                }
            }
            if(count==0)
            {
                Console.WriteLine("Take Vaccination immediately ");
            }
        }

    }
}
public enum VaccineType
{
    Covaxin = 1, Covidshield, sputnik
}

