﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaccinationRegistration1
{

    class BeneficiaryDetails
    {
        private static int _userId = 1001;
        public int userId;
        public string userName { get; set; }

        public int age { get; set; }

        public long mobilenumber { get; set; }
        public BeneficiaryDetails(string userName, int age, long mobilenumber)
        {
            this.userId = _userId;
            Console.WriteLine("The user id is:" + this.userId);
            _userId++;
            this.userName = userName;
            this.age = age;
            this.mobilenumber = mobilenumber;
        }
    }
}
