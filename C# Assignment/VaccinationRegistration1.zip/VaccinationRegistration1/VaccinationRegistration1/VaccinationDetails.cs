﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaccinationRegistration1
{
   public class VaccinationDetails
    {
        private static int _medicalId = 30001;
        public int medicalID;
        public int userId { get; set; }
        public string username { get; set; }
        public string vaccinename { get; set; }
        public int dose { get; set; }

        DateTime date;

        public VaccinationDetails(int userid, string username, string vaccinename, int dose,DateTime date)
        {
            this.medicalID = _medicalId;
            _medicalId++;
            this.userId = userid;
            this.username = username;
            this.vaccinename = vaccinename;
            this.dose = dose;
            

            

        }
    }
}
